# FarmLandy - Quick Start Guide

## ⚡ Deploy in 10 Minutes

---

## Step 1: Prepare Your Files (2 minutes)

### Folder Structure
```
FarmLandy/
├── FarmLandy/
│   ├── __init__.py
│   ├── settings.py      ✅ (Use provided file)
│   ├── urls.py          ✅ (Use provided file)
│   ├── wsgi.py          ✅ (Use provided file)
│   └── asgi.py
├── customerapp/
│   ├── __init__.py
│   ├── admin.py         ✅ (Use provided file)
│   ├── apps.py          ✅ (Use provided file)
│   ├── forms.py         ✅ (Copy from your PyCharm)
│   ├── models.py        ✅ (Copy from your PyCharm)
│   ├── urls.py          ✅ (Use provided file)
│   └── views.py         ✅ (Copy from your PyCharm)
├── adminsapp/
│   ├── __init__.py
│   ├── admin.py         ✅ (Use provided file)
│   ├── apps.py          ✅ (Use provided file)
│   ├── forms.py         ✅ (Use provided file)
│   ├── models.py        ✅ (Copy models(1).py, rename)
│   ├── urls.py          ✅ (Use provided file)
│   └── views.py         ✅ (Copy views(1).py, rename)
├── templates/           ✅ (Copy ALL HTML files from PyCharm)
├── static/              ✅ (Copy ALL CSS/JS/IMAGES from PyCharm)
├── manage.py            ✅ (Use provided file)
├── requirements.txt     ✅ (Use provided file)
├── vercel.json          ✅ (Use provided file)
└── .gitignore           ✅ (Use provided file)
```

---

## Step 2: Create GitHub Repository (2 minutes)

1. Go to [github.com/new](https://github.com/new)
2. Enter Repository Name: `FarmLandy`
3. Check "Add a README file"
4. Click **Create repository**
5. Click **"Uploading an existing file"**
6. Drag and drop all your project files
7. Click **Commit changes**

---

## Step 3: Setup Database (2 minutes)

### Option A: Neon PostgreSQL (Free)

1. Go to [neon.tech](https://neon.tech)
2. Sign up with GitHub
3. Create new project → Name: `farmlandy`
4. Copy the connection string

### Option B: Supabase (Free)

1. Go to [supabase.com](https://supabase.com)
2. Create new project
3. Go to Settings → Database
4. Copy connection string

---

## Step 4: Deploy to Vercel (3 minutes)

1. Go to [vercel.com/new](https://vercel.com/new)
2. Import your `FarmLandy` GitHub repository
3. Configure:
   - Framework Preset: **Other**
   - Root Directory: `./`
4. Click **Environment Variables** and add:

| Name | Value |
|------|-------|
| `DATABASE_URL` | Your database connection string |
| `SECRET_KEY` | `django-insecure-your-random-key-here` |
| `DEBUG` | `False` |

5. Click **Deploy**

---

## Step 5: Run Migrations (1 minute)

After deployment, run migrations:

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Run migrations (in project folder)
vercel --prod
```

Or use Vercel Dashboard → Functions → Console

---

## ✅ Done!

Your site is live at: `https://farmlandy.vercel.app`

---

## 🔧 Troubleshooting

### Static files not loading?
- Check `STATIC_ROOT` in settings.py
- Run `python manage.py collectstatic`

### Database errors?
- Verify DATABASE_URL format
- Check database is accessible

### 500 errors?
- Check Vercel logs (Dashboard → Functions)
- Verify environment variables

---

## 📞 Need Help?

1. Check full guide: [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)
2. Review Vercel logs
3. Check Django error messages

---

**Happy Deploying! 🚀**
