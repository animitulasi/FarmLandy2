# FarmLandy Deployment Guide
## Complete Guide to Deploy Django Project on GitHub + Vercel

---

## Table of Contents
1. [Project Overview](#project-overview)
2. [Prerequisites](#prerequisites)
3. [Step 1: Organize Project Files](#step-1-organize-project-files)
4. [Step 2: Create GitHub Repository](#step-2-create-github-repository)
5. [Step 3: Database Setup](#step-3-database-setup)
6. [Step 4: Vercel Deployment](#step-4-vercel-deployment)
7. [Step 5: Environment Variables](#step-5-environment-variables)
8. [Troubleshooting](#troubleshooting)

---

## Project Overview

**FarmLandy** is a Django-based Farm Land Marketplace with:
- **Customer Portal**: Registration, Login, Property Management, Bookings, Services
- **Admin Portal**: Customer Management, Property Approval, Services, Notifications
- **Database**: MySQL (local) → PostgreSQL (production)
- **Tech Stack**: Django, Python, HTML/CSS/JS

---

## Prerequisites

Before starting, ensure you have:

1. **GitHub Account**: [Sign up here](https://github.com)
2. **Vercel Account**: [Sign up here](https://vercel.com) (use GitHub login)
3. **Git Installed**: [Download Git](https://git-scm.com/downloads)
4. **Python 3.9+**: [Download Python](https://python.org)
5. **Your PyCharm Project Files**: All the files you uploaded

---

## Step 1: Organize Project Files

### 1.1 Create Project Structure

Create a folder on your desktop called `FarmLandy-Deploy` with this structure:

```
FarmLandy-Deploy/
├── FarmLandy/                 # Main project folder
│   ├── __init__.py
│   ├── settings.py           # Will modify this
│   ├── urls.py
│   ├── wsgi.py               # Will modify this
│   └── asgi.py
├── customerapp/               # Customer app
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── forms.py
│   ├── models.py
│   ├── tests.py
│   └── views.py
├── adminsapp/                 # Admin app
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── forms.py
│   ├── models.py
│   ├── tests.py
│   └── views.py
├── templates/                 # All HTML templates
│   ├── index.html
│   ├── about.html
│   ├── contact.html
│   ├── customer.html
│   ├── customer_home.html
│   ├── admin.html
│   ├── admin_home.html
│   └── ... (all other templates)
├── static/                    # CSS, JS, Images
│   ├── css/
│   ├── js/
│   └── images/
├── media/                     # User uploaded files
├── manage.py
├── requirements.txt           # Dependencies
├── vercel.json               # Vercel config
├── .gitignore
└── README.md
```

### 1.2 Copy Your Files

From your PyCharm project, copy these files:

**Main Project Files (FarmLandy/):**
- `settings.py`
- `urls.py`
- `wsgi.py`
- `__init__.py`

**Customer App (customerapp/):**
- `models.py` → use the first models.py file
- `views.py` → use the first views.py file
- `forms.py` → use the first forms.py file
- `admin.py`, `apps.py`, `tests.py`, `__init__.py`

**Admin App (adminsapp/):**
- `models.py` → use models(1).py (rename to models.py)
- `views.py` → use views(1).py (rename to views.py)
- `forms.py` → use forms(1).py (rename to forms.py)
- `admin.py`, `apps.py`, `tests.py`, `__init__.py`

**Root Files:**
- `manage.py`

---

## Step 2: Create GitHub Repository

### 2.1 Create New Repository

1. Go to [GitHub](https://github.com) and login
2. Click the **+** icon (top right) → **New repository**
3. Fill in details:
   - **Repository name**: `FarmLandy`
   - **Description**: `Farm Land Marketplace - Django Web Application`
   - **Visibility**: Public (or Private)
   - **Initialize with README**: ✅ Check this
   - **Add .gitignore**: Python
   - **License**: MIT (optional)
4. Click **Create repository**

### 2.2 Upload Files to GitHub

#### Option A: Using Git Command Line (Recommended)

Open terminal/command prompt in your `FarmLandy-Deploy` folder:

```bash
# Initialize git
git init

# Add all files
git add .

# Commit files
git commit -m "Initial commit - FarmLandy Django Project"

# Add remote repository (replace with your actual repo URL)
git remote add origin https://github.com/YOUR_USERNAME/FarmLandy.git

# Push to GitHub
git branch -M main
git push -u origin main
```

#### Option B: Using GitHub Web Interface

1. Go to your repository on GitHub
2. Click **"Add file"** → **"Upload files"**
3. Drag and drop all your project files
4. Click **"Commit changes"**

---

## Step 3: Database Setup

### 3.1 Understanding Database Options

| Option | Best For | Difficulty |
|--------|----------|------------|
| **Vercel Postgres** | Serverless, auto-scaling | Easy |
| **Neon** | Free tier, serverless | Easy |
| **Supabase** | Free tier, great features | Easy |
| **Railway** | Simple deployment | Medium |

### 3.2 Setup Neon PostgreSQL (Recommended - Free)

1. Go to [Neon](https://neon.tech) and sign up
2. Create new project:
   - **Project name**: `farmlandy`
   - **Database name**: `farmlandy`
   - **Region**: Choose closest to your users
3. Get connection string:
   - Click on your project
     - Go to **"Connection Details"**
   - Copy the **Database URL** (looks like):
     ```
     postgres://username:password@host.neon.tech/farmlandy?sslmode=require
     ```

### 3.3 Update Django Settings

Create/modify `FarmLandy/settings.py`:

```python
import os
from pathlib import Path
import dj_database_url
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key secret!
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-default-secret-key-change-in-production')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = os.environ.get('DEBUG', 'False') == 'True'

ALLOWED_HOSTS = [
    'localhost',
    '127.0.0.1',
    '.vercel.app',
    os.environ.get('VERCEL_URL', '')
]

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'customerapp',
    'adminsapp',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'FarmLandy.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'FarmLandy.wsgi.application'

# Database Configuration
DATABASES = {
    'default': dj_database_url.config(
        default=os.environ.get('DATABASE_URL'),
        conn_max_age=600
    )
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [
    BASE_DIR / 'static',
]

# WhiteNoise for static files
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Session settings
SESSION_ENGINE = 'django.contrib.sessions.backends.db'
SESSION_COOKIE_AGE = 86400  # 24 hours
```

### 3.4 Create WSGI for Vercel

Modify `FarmLandy/wsgi.py`:

```python
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'FarmLandy.settings')

application = get_wsgi_application()

# For Vercel serverless
app = application
```

---

## Step 4: Vercel Deployment

### 4.1 Install Vercel CLI (Optional)

```bash
npm install -g vercel
```

### 4.2 Create vercel.json

Create `vercel.json` in your project root:

```json
{
  "version": 2,
  "builds": [
    {
      "src": "FarmLandy/wsgi.py",
      "use": "@vercel/python",
      "config": {
        "maxLambdaSize": "15mb",
        "runtime": "python3.9"
      }
    }
  ],
  "routes": [
    {
      "src": "/static/(.*)",
      "dest": "/static/$1"
    },
    {
      "src": "/media/(.*)",
      "dest": "/media/$1"
    },
    {
      "src": "/(.*)",
      "dest": "FarmLandy/wsgi.py"
    }
  ],
  "env": {
    "DJANGO_SETTINGS_MODULE": "FarmLandy.settings"
  }
}
```

### 4.3 Create requirements.txt

```
Django==4.2.7
mysqlclient==2.2.0
Pillow==10.1.0
python-dotenv==1.0.0
whitenoise==6.6.0
gunicorn==21.2.0
psycopg2-binary==2.9.9
dj-database-url==2.1.0
```

### 4.4 Deploy to Vercel

#### Option A: Via Vercel Dashboard (Recommended)

1. Go to [Vercel Dashboard](https://vercel.com/dashboard)
2. Click **"Add New Project"**
3. Import from GitHub:
   - Find and select your `FarmLandy` repository
   - Click **"Import"**
4. Configure Project:
   - **Framework Preset**: Other
   - **Root Directory**: ./
   - **Build Command**: (leave empty)
   - **Output Directory**: (leave empty)
5. Add Environment Variables:
   - Click **"Environment Variables"**
   - Add these:
     ```
     DATABASE_URL = your-neon-database-url
     SECRET_KEY = your-random-secret-key
     DEBUG = False
     ```
6. Click **"Deploy"**

#### Option B: Via Vercel CLI

```bash
# Login to Vercel
vercel login

# Deploy
vercel

# Follow prompts
# ? Set up and deploy? [Y/n] Y
# ? Link to existing project? [y/N] N
# ? What's your project name? farmlandy
```

---

## Step 5: Environment Variables

### 5.1 Required Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgres://user:pass@host/db` |
| `SECRET_KEY` | Django secret key | `django-insecure-...` |
| `DEBUG` | Debug mode | `False` |
| `ALLOWED_HOSTS` | Allowed hosts | `.vercel.app` |

### 5.2 Generate Secret Key

```python
# Run this in Python to generate a secret key
import secrets
print(secrets.token_urlsafe(50))
```

### 5.3 Set Environment Variables in Vercel

1. Go to [Vercel Dashboard](https://vercel.com/dashboard)
2. Select your project
3. Go to **Settings** → **Environment Variables**
4. Add each variable:
   - Name: `DATABASE_URL`
   - Value: `your-database-url`
   - Environment: Production, Preview, Development

---

## Step 6: Run Migrations

### 6.1 Local Migration (Before Deploy)

```bash
# Create migrations
python manage.py makemigrations

# Apply migrations
python manage.py migrate
```

### 6.2 On Vercel (Using CLI)

```bash
# Install Vercel CLI
npm i -g vercel

# Run migration command
vercel --prod
```

---

## Step 7: Alternative Deployment (Recommended for Full Django)

Since Vercel has limitations with Django (serverless), consider these alternatives:

### 7.1 Railway (Easiest for Django)

1. Go to [Railway](https://railway.app)
2. Sign up with GitHub
3. Click **"New Project"**
4. Select **"Deploy from GitHub repo"**
5. Choose your `FarmLandy` repository
6. Add PostgreSQL:
   - Click **"New"** → **"Database"** → **"Add PostgreSQL"**
7. Add environment variables
8. Deploy!

### 7.2 Render (Free Tier)

1. Go to [Render](https://render.com)
2. Sign up with GitHub
3. Click **"New"** → **"Web Service"**
4. Connect your GitHub repository
5. Configure:
   - **Name**: farmlandy
   - **Runtime**: Python
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn FarmLandy.wsgi:application`
6. Add PostgreSQL database
7. Deploy!

---

## Troubleshooting

### Common Issues

#### Issue 1: Static Files Not Loading
**Solution**: Ensure whitenoise is configured properly

#### Issue 2: Database Connection Failed
**Solution**: Check DATABASE_URL format and network access

#### Issue 3: Module Not Found
**Solution**: Ensure all dependencies in requirements.txt

#### Issue 4: 504 Gateway Timeout
**Solution**: Vercel has 10s timeout - use Railway/Render for long operations

---

## Quick Reference Commands

```bash
# Git commands
git add .
git commit -m "message"
git push origin main

# Django commands
python manage.py runserver
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py collectstatic

# Vercel commands
vercel login
vercel
vercel --prod
```

---

## Next Steps

1. ✅ Organize your files as shown
2. ✅ Create GitHub repository
3. ✅ Push code to GitHub
4. ✅ Set up PostgreSQL database (Neon/Railway)
5. ✅ Deploy to Vercel/Railway/Render
6. ✅ Configure environment variables
7. ✅ Run migrations
8. ✅ Test your application

---

## Support

If you encounter issues:
- Check Vercel logs in Dashboard
- Review Django error messages
- Verify database connection
- Check environment variables

---

**Good luck with your deployment! 🚀**
