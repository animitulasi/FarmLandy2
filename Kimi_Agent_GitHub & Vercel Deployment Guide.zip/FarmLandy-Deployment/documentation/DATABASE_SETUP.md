# Database Setup Guide for FarmLandy

## Converting MySQL to PostgreSQL

---

## Option 1: Neon PostgreSQL (Recommended - Free Tier)

### Step 1: Create Account
1. Go to [neon.tech](https://neon.tech)
2. Sign up with GitHub
3. Verify email

### Step 2: Create Project
1. Click **"New Project"**
2. Project Name: `farmlandy`
3. Database Name: `farmlandy`
4. Region: Select closest to your users (e.g., `Asia Pacific (Singapore)`)
5. Click **"Create Project"**

### Step 3: Get Connection String
1. In your project dashboard
2. Click **"Connection Details"**
3. Copy the **Database URL**
   ```
   postgres://username:password@host.neon.tech/farmlandy?sslmode=require
   ```

### Step 4: Add to Vercel
1. Go to Vercel Dashboard → Your Project
2. Settings → Environment Variables
3. Add:
   - Name: `DATABASE_URL`
   - Value: `postgres://username:password@host.neon.tech/farmlandy?sslmode=require`

---

## Option 2: Supabase PostgreSQL (Free Tier)

### Step 1: Create Account
1. Go to [supabase.com](https://supabase.com)
2. Sign up with GitHub

### Step 2: Create Project
1. Click **"New Project"**
2. Organization: Your org
3. Project Name: `farmlandy`
4. Database Password: Create strong password
5. Region: Closest to users
6. Click **"Create New Project"**

### Step 3: Get Connection String
1. Go to Project Settings (gear icon)
2. Click **"Database"**
3. Under **"Connection string"**, select **"URI"**
4. Copy the connection string
   ```
   postgresql://postgres:[PASSWORD]@db.[PROJECT_REF].supabase.co:5432/postgres
   ```

---

## Option 3: Railway PostgreSQL

### Step 1: Create Account
1. Go to [railway.app](https://railway.app)
2. Sign up with GitHub

### Step 2: Add Database
1. Create New Project
2. Click **"New"** → **"Database"** → **"Add PostgreSQL"**
3. Database will be created automatically

### Step 3: Get Variables
1. Click on the PostgreSQL service
2. Go to **"Variables"** tab
3. Copy `DATABASE_URL`

---

## Migrating Data from MySQL to PostgreSQL

### Method 1: Using Django Fixtures

```bash
# From your local MySQL project
python manage.py dumpdata > data.json

# In your new PostgreSQL project
python manage.py loaddata data.json
```

### Method 2: Using pgLoader (Advanced)

```bash
# Install pgLoader
sudo apt-get install pgloader

# Create migration script
pgloader mysql://user:pass@localhost/farmlandy postgresql://user:pass@host/farmlandy
```

### Method 3: Manual Export/Import

1. Export MySQL data as SQL
2. Convert SQL syntax (use online converters)
3. Import to PostgreSQL

---

## Database Schema

Your FarmLandy database includes these tables:

| Table | Purpose |
|-------|---------|
| `auth_user` | Django users |
| `customerapp_customer_reg` | Customer registrations |
| `customerapp_properties` | Property listings |
| `customerapp_contact` | Contact form submissions |
| `visit` | Site visit bookings |
| `add_services` | Available services |
| `book_services` | Service bookings |
| `notifications` | Admin notifications |
| `adminsapp_admin` | Admin users |

---

## Environment Variables

Add these to your deployment platform:

```env
# Required
DATABASE_URL=postgres://user:pass@host/db?sslmode=require
SECRET_KEY=your-django-secret-key
DEBUG=False

# Optional
ALLOWED_HOSTS=.vercel.app,.railway.app
```

---

## Testing Database Connection

```python
# Test in Python shell
import psycopg2

conn = psycopg2.connect("your-database-url")
cursor = conn.cursor()
cursor.execute("SELECT version();")
print(cursor.fetchone())
conn.close()
```

---

## Common Issues

### SSL Mode Required
Add `?sslmode=require` to your connection string

### Connection Timeout
- Check firewall settings
- Verify IP whitelist
- Use correct port (5432)

### Permission Denied
- Verify username/password
- Check database exists
- Grant proper permissions

---

## Free Tier Limits

| Provider | Storage | Connections | Notes |
|----------|---------|-------------|-------|
| Neon | 500 MB | 100 | Auto-suspend after inactivity |
| Supabase | 500 MB | 60 | Pauses after 7 days inactivity |
| Railway | 500 MB | Unlimited | $5 credit/month |

---

## Next Steps

1. ✅ Choose database provider
2. ✅ Create database
3. ✅ Get connection string
4. ✅ Add to environment variables
5. ✅ Run migrations
6. ✅ Test connection

---

**Your database is ready! 🎉**
