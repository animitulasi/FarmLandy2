#!/bin/bash
# FarmLandy Deployment Setup Script

echo "=========================================="
echo "  FarmLandy Deployment Setup"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}Python 3 is not installed. Please install Python 3.9+${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Python found${NC}"

# Check Python version
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $PYTHON_VERSION"

# Create virtual environment
echo ""
echo -e "${YELLOW}Creating virtual environment...${NC}"
python3 -m venv venv

# Activate virtual environment
echo -e "${YELLOW}Activating virtual environment...${NC}"
source venv/bin/activate 2>/dev/null || source venv/Scripts/activate

# Install dependencies
echo ""
echo -e "${YELLOW}Installing dependencies...${NC}"
pip install --upgrade pip
pip install -r requirements.txt

# Create .env file if not exists
if [ ! -f .env ]; then
    echo ""
    echo -e "${YELLOW}Creating .env file...${NC}"
    cat > .env << EOF
SECRET_KEY=django-insecure-change-this-in-production
DEBUG=True
DATABASE_URL=
EOF
    echo -e "${GREEN}✓ .env file created. Please update with your values.${NC}"
fi

# Run migrations
echo ""
echo -e "${YELLOW}Running migrations...${NC}"
python manage.py makemigrations
python manage.py migrate

# Create superuser
echo ""
echo -e "${YELLOW}Create superuser? (y/n)${NC}"
read -r response
if [ "$response" = "y" ]; then
    python manage.py createsuperuser
fi

# Collect static files
echo ""
echo -e "${YELLOW}Collecting static files...${NC}"
python manage.py collectstatic --noinput

echo ""
echo "=========================================="
echo -e "${GREEN}Setup complete!${NC}"
echo "=========================================="
echo ""
echo "To start the development server:"
echo "  source venv/bin/activate"
echo "  python manage.py runserver"
echo ""
echo "Visit: http://127.0.0.1:8000"
echo ""
