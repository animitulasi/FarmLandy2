# 🚀 FarmLandy Deployment - START HERE

Welcome! This folder contains everything you need to deploy your FarmLandy Django project to GitHub and Vercel.

---

## 📁 What's Inside?

```
FarmLandy-Deployment/
├── 📁 project-files/          # Django project files (ready to use)
│   ├── FarmLandy/            # Main project settings (configured for deployment)
│   ├── customerapp/          # Customer portal files
│   ├── adminsapp/            # Admin portal files
│   ├── templates/            # HTML templates folder
│   ├── static/               # CSS, JS, Images folder
│   └── manage.py             # Django management script
│
├── 📁 deployment-config/      # Configuration files
│   ├── requirements.txt      # Python dependencies
│   ├── vercel.json          # Vercel deployment config
│   ├── .gitignore           # Git ignore rules
│   ├── runtime.txt          # Python version
│   └── setup.sh             # Automated setup script
│
├── 📁 database/              # Database files
│   └── (your SQL dump here)
│
└── 📁 documentation/         # Guides and instructions
    ├── DEPLOYMENT_GUIDE.md  # Complete deployment guide
    ├── QUICK_START.md       # 10-minute quick start
    └── DATABASE_SETUP.md    # Database configuration
```

---

## ⚡ Quick Start (10 Minutes)

### Step 1: Copy Your Files

1. Copy your **HTML templates** from PyCharm to `project-files/templates/`
2. Copy your **static files** (CSS, JS, images) to `project-files/static/`
3. Your Python files are already included!

### Step 2: Create GitHub Repository

1. Go to [github.com/new](https://github.com/new)
2. Name: `FarmLandy`
3. Upload all files from `project-files/`

### Step 3: Deploy to Vercel

1. Go to [vercel.com/new](https://vercel.com/new)
2. Import your GitHub repository
3. Add environment variables (see below)
4. Deploy!

---

## 🔑 Required Environment Variables

| Variable | How to Get |
|----------|------------|
| `DATABASE_URL` | [Neon PostgreSQL](https://neon.tech) - Free 500MB |
| `SECRET_KEY` | Run: `python -c "import secrets; print(secrets.token_urlsafe(50))"` |
| `DEBUG` | Set to `False` for production |

---

## 📖 Documentation

| Document | Purpose |
|----------|---------|
| [DEPLOYMENT_GUIDE.md](documentation/DEPLOYMENT_GUIDE.md) | Complete step-by-step guide |
| [QUICK_START.md](documentation/QUICK_START.md) | Fast 10-minute deployment |
| [DATABASE_SETUP.md](documentation/DATABASE_SETUP.md) | Database configuration |

---

## 🎯 Deployment Options

### Option 1: Vercel (Serverless)
- ✅ Free tier
- ⚠️ 10-second timeout limit
- ⚠️ Best for small projects

### Option 2: Railway (Recommended)
- ✅ $5 free credit/month
- ✅ Full Django support
- ✅ Easy PostgreSQL integration

### Option 3: Render
- ✅ Free tier available
- ✅ Full Django support
- ✅ Automatic deployments

---

## 🛠️ Local Development

```bash
# 1. Navigate to project folder
cd project-files

# 2. Create virtual environment
python -m venv venv

# 3. Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 4. Install dependencies
pip install -r ../deployment-config/requirements.txt

# 5. Run migrations
python manage.py migrate

# 6. Start server
python manage.py runserver
```

Visit: http://127.0.0.1:8000

---

## 📞 Troubleshooting

| Problem | Solution |
|---------|----------|
| Static files not loading | Check `STATIC_ROOT` in settings.py |
| Database connection failed | Verify DATABASE_URL format |
| 500 errors | Check Vercel logs |
| Module not found | Install from requirements.txt |

---

## ✅ Checklist

- [ ] Copy HTML templates to `project-files/templates/`
- [ ] Copy static files to `project-files/static/`
- [ ] Create GitHub repository
- [ ] Setup PostgreSQL database (Neon/Supabase)
- [ ] Deploy to Vercel/Railway/Render
- [ ] Add environment variables
- [ ] Run migrations
- [ ] Test the application

---

## 🎉 Next Steps

1. Read [QUICK_START.md](documentation/QUICK_START.md) for detailed steps
2. Setup your database using [DATABASE_SETUP.md](documentation/DATABASE_SETUP.md)
3. Deploy and share your project!

---

**Good luck with your deployment! 🚀**

Need help? Check the documentation folder or search for errors online.
