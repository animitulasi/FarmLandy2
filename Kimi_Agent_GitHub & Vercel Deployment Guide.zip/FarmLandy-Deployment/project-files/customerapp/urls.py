"""
URL configuration for customerapp.
"""
from django.urls import path
from . import views

urlpatterns = [
    # Public pages
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('blog/', views.blog, name='blog'),
    path('blog-single/', views.blog_single, name='blog_single'),
    path('project/', views.project, name='project'),
    path('services/', views.services, name='services'),
    
    # Customer authentication
    path('customer/', views.customer, name='customer'),
    path('customer-registration/', views.customer_registration, name='customer_registration'),
    path('customer-login/', views.customer_login, name='customer_login'),
    path('logout/', views.logout, name='logout'),
    
    # Customer dashboard
    path('customer-home/', views.customer_home, name='customer_home'),
    path('my-profile/', views.my_profile, name='my_profile'),
    path('c-update/', views.c_update, name='c_update'),
    path('u-update/', views.u_update, name='u_update'),
    path('change-pwd/', views.change_pwd, name='change_pwd'),
    
    # Properties
    path('post-properties/', views.post_properties, name='post_properties'),
    path('add-property/', views.add_property, name='add_property'),
    path('view-my-properties/', views.view_my_properties, name='view_my_properties'),
    path('view-properties/', views.view_properties, name='view_properties'),
    path('customer-edit/<int:id>/', views.customer_edit, name='customer_edit'),
    path('update-property/', views.update_property, name='update_property'),
    path('customer-delete/<int:id>/', views.customer_all_delete, name='customer_all_delete'),
    
    # Site visits / Slots
    path('sitevisit/<int:id>/', views.sitevisit, name='sitevisit'),
    path('slots/', views.slots, name='slots'),
    path('visitersite/<int:id>/', views.visitersite, name='visitersite'),
    path('approve-slot/<int:site_id>/', views.approve_slot, name='approve_slot'),
    path('reject-slot/<int:site_id>/', views.reject_slot, name='reject_slot'),
    
    # Services
    path('customers-view-services/', views.customers_view_services, name='customers_view_services'),
    path('book-services/<int:id>/', views.book_services, name='book_services'),
    path('customers-my-bookings-services/', views.customers_my_bookings_services, name='customers_my_bookings_services'),
    
    # Notifications
    path('customers-view-notifications/', views.customers_view_notifications, name='customers_view_notifications'),
]
