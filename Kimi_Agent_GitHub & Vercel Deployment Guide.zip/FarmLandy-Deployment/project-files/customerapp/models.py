from django.db import models


# Create your models here.

class Contact(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=254)
    subject = models.CharField(max_length=100)
    message = models.TextField()


class Customer_reg(models.Model):
    email = models.EmailField(max_length=254)
    password = models.CharField(max_length=50)
    fullname = models.CharField(max_length=50)
    mobile = models.BigIntegerField()
    city = models.CharField(max_length=50)

    address = models.TextField()

    pincode = models.BigIntegerField()
    profile = models.FileField()
    status = models.CharField(max_length=100, default="On Hold")



class Customer_pic(models.Model):
    email = models.EmailField(max_length=254)
    image = models.ImageField(upload_to='images/')


class Properties(models.Model):
    email = models.EmailField(max_length=150)
    title = models.CharField(max_length=50)
    farm_landing_type = models.CharField(max_length=30)
    address = models.TextField()
    area = models.CharField(max_length=30)
    cost = models.IntegerField()
    city = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='images/')
    status = models.CharField(max_length=100, default="Pending")



class Propertyvisit(models.Model):
    property_id= models.ForeignKey(Properties, on_delete=models.CASCADE)
    user_id = models.ForeignKey(Customer_reg, on_delete=models.CASCADE)
    description=models.TextField(max_length=500)
    datetime = models.DateTimeField()
    slotstatus=models.IntegerField(default=0)

    class Meta:
        db_table = "visit"

class Add_Services(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    cost = models.BigIntegerField()

    class Meta:

        db_table = "Add_Services"

class Book_Services(models.Model):
    services = models.ForeignKey(Add_Services,on_delete=models.CASCADE)
    email = models.EmailField()
    title = models.CharField(max_length=100)
    cost = models.BigIntegerField()
    bookings_datetime = models.DateTimeField(auto_now=True)

    status = models.CharField(max_length=100, default="Pending")

    class Meta:
        db_table = "Book_Services"

