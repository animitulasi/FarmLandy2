from customerapp.models import Contact,Customer_reg,Customer_pic,Properties,Propertyvisit, Add_Services, Book_Services
from django import forms

class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = "__all__"


class Customer_regForm(forms.ModelForm):
    class Meta:
        model = Customer_reg
        exclude = ["status"]

class PropertiesForm(forms.ModelForm):
    class Meta:
        model = Properties
        exclude = ["status"]

class Customer_picForm(forms.ModelForm):
    class Meta:
        model = Customer_pic
        fields = "__all__"


class PropertyvisitForm(forms.ModelForm):
    class Meta:
        model = Propertyvisit
        fields = ('property_id','user_id','description','datetime')

class Add_ServicesForms(forms.ModelForm):
    class Meta:
        model = Add_Services
        fields = "__all__"

class Book_ServicesForms(forms.ModelForm):
    class Meta:
        model = Book_Services
        exclude = ["status"]

