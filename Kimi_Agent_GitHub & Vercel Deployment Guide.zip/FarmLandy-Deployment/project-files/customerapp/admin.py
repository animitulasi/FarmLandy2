from django.contrib import admin
from .models import Contact, Customer_reg, Customer_pic, Properties, Propertyvisit, Add_Services, Book_Services

# Register your models here.
admin.site.register(Contact)
admin.site.register(Customer_reg)
admin.site.register(Customer_pic)
admin.site.register(Properties)
admin.site.register(Propertyvisit)
admin.site.register(Add_Services)
admin.site.register(Book_Services)
