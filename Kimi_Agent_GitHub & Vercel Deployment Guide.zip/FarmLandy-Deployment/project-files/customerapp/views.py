import smtplib

from django.contrib import messages
from django.shortcuts import render, redirect
from customerapp.models import Contact, Customer_reg, Customer_pic, Properties,Propertyvisit, Add_Services, Book_Services
from customerapp.forms import ContactForm, Customer_regForm, Customer_picForm, PropertiesForm,PropertyvisitForm, Book_ServicesForms
from adminsapp.models import Notifications
# Create your views here.

def about(request):
    return render(request, "about.html", {})


def blog(request):
    return render(request, "blog.html", {})


def blog_single(request):
    return render(request, "blog-single.html", {})


def contact(request):
    if request.method=="POST":
        contact=ContactForm(request.POST)
        if contact.is_valid():
            contact.save()
            messages.success(request, "Thanks For Contacting Us")
            return redirect("/contact")
    return render(request, "contact.html", {})



def index(request):
    return render(request, "index.html", {})


def project(request):
    return render(request, "project.html", {})


def services(request):
    return render(request, "services.html", {})


def contact_info(request):
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, "contact.html", {"msg": "Contact Posted"})
    return render(request, "contact.html", {})


def customer(request):
    return render(request, "customer.html", {})




def customer_registration(request):
    if request.method == "POST":
        form = Customer_regForm(request.POST, request.FILES)
        print(form.errors)
        email = request.POST.get("email", " ")
        if Customer_reg.objects.filter(email=email).exists():
            return render(request, "customer_reg.html", {"msg": " This Email is Already Exist Can You Please Try With Another Email?"})
        else:
            if form.is_valid():
                form.save()
                messages.success(request, "Successfully Registered!")
                return redirect("/customer")
            else:
                return render(request, "customer_reg.html", {"msg": "No Data Post"})
    form = Customer_regForm()
    return render(request, "customer_reg.html", {"form": form})


def customer_login(request):
    if request.method == "POST":
        email = request.POST["email"]
        password = request.POST["password"]
        print(email, "", password)
        login = Customer_reg.objects.filter(email=email, password=password)
        if login.exists():
            print("hi")
            if login[0].status == "Accepted":
                request.session['email'] = email
                client = Customer_reg.objects.get(email=email)
                return render(request, "customer_home.html", {"msg": "Successfully Login"})
            else:
                return render(request, "customer.html", {"msg": "Your Account Is On Hold !"})
        else:
            return render(request, "customer.html", {"msg": "Invalid Data"})
    return render(request, "customer.html", {})

def post_properties(request):
    email = request.session['email']
    return render(request, "post_properties.html", {'email1': email})


def add_property(request):
    if request.method == "POST":
        details = PropertiesForm(request.POST, request.FILES)
        if details.is_valid():
            try:
                details.save()
                return redirect("/view_my_properties")
            except:
                return render(request, 'post_properties.html', {})
    return render(request, "post_properties.html", {})


def is_login(request):
    if request.session.__contains__('email'):
        return True
    else:
        return False



def change_pwd(request):
    email = request.session.get("email")
    if not email:
        return redirect('/customer')

    if is_login(request):
        if request.method == 'POST':
            password = request.POST.get('password')
            new_password = request.POST.get('new_password')

            # Check if the old password and new password are the same
            if password == new_password:
                messages.error(request, "Your Old Password And New Password Are The Same.")
                return redirect('/change_pwd')

            # Verify old password and update new password

            try:
                user = Customer_reg.objects.get(email=email, password=password)
                user.password = new_password
                user.save()
                messages.success(request, 'Successfully Password Changed.')
                return redirect('/customer')
            except Customer_reg.DoesNotExist:
                messages.error(request, "Invalid Old Password.")

                return redirect('/change_pwd')
        return render(request, "customer_chng_pwd.html", {"email": email})
    else:
        return redirect('/customer')

def view_my_properties(request):
    email = request.session['email']
    properties = Properties.objects.filter(email=email)
    return render(request, "view_my_properties.html", {'properties': properties})


def view_properties(request):
    email = request.session['email']
    others_prop=Properties.objects.exclude(email=email).filter(status="Accepted")
    return render(request, "view_properties.html", {'others_prop':others_prop})




def logout(request):
    request.session['email'] = ''
    return redirect("/customer")
    # return render(request, "customer.html", {"msg": "Logout success"})


def customer_home(request):
    return render(request, "customer_home.html", {})


def customer_all_delete(request,id):
    query = Properties.objects.get(id=id)
    query.delete()
    return redirect("/view_my_properties")


def customer_edit(request,id):
    query = Properties.objects.get(id=id)
    return render(request, "edit_my_properties.html", {'query': query})


def update_property(request):
    if request.method == "POST":
        id=request.POST["id"]
        query=Properties.objects.get(id=id)
        query = PropertiesForm(request.POST, request.FILES, instance=query)
        if query.is_valid():
            query.save()
            return redirect("/view_my_properties")
    return redirect("/view_my_properties")


def sitevisit(request,id):
    email = request.session['email']
    print("hii")
    customer = Customer_reg.objects.get(email=email)
    print("hiihaiii")
    addproperty = Properties.objects.get(id=id)
    if request.method == "POST":
        print("hrrrrr")
        sitevisit = PropertyvisitForm(request.POST)
        print('hi')
        print(sitevisit.errors)
        if sitevisit.is_valid():
            print("hii555")
            print(sitevisit.errors)
            sitevisit.save()
            return redirect("/slots")
    return render(request, "site_visit.html", {"id": addproperty.id, "customer": customer.id})


def slots(request):
    email = request.session['email']
    customer = Customer_reg.objects.get(email=email)
    print("hi11")
    propeties = Propertyvisit.objects.filter(user_id=customer.id)
    return render(request, "slots.html", {"sites": propeties})



def visitersite(request, id ):
    visiter=Propertyvisit.objects.filter(property_id=id)
    return render(request,"bookslots.html", {"sites": visiter})


def approve_slot(request, site_id):
    approve=Propertyvisit.objects.get(id=site_id)
    approve.slotstatus = 1
    approve.save()
    return redirect("/view_my_properties")


def reject_slot(request, site_id):
    reject=Propertyvisit.objects.get(id=site_id)
    reject.slotstatus = 2
    reject.save()
    return redirect("/view_my_properties")




"""def customer_edit(request):
    email=request.session["email"]
    query=Properties.objects.get(email=email)
    return render(request,"edit_my_properties.html",{"query":query})

def customer_update(request):
    if request.method == "POST":
        try:
            email = request.session["email"]
            print("h")
            query = Properties.objects.get(email=email)
            query.title = request.POST["title"]
            query.address = request.POST["address"]
            query. area = request.POST["area"]
            query. cost=request.POST["cost"]
            query.description = request.POST["description"]
            query.save()
            print("HI")

            return redirect("/view_my_properties")

        except Exception as a:
            print(a)
            return render(request, 'edit_my_properties.html', {})

    return render(request, "edit_my_properties.html", {})"""


def my_profile(request):
    email = request.session["email"]
    profile = Customer_reg.objects.get(email=email)
    return render(request,"my_profile.html",{"profile":profile})

def u_update(request):
    if request.method == "POST":
        id = request.POST["id"]
        user = Customer_reg.objects.get(id=id)
        form = Customer_regForm(request.POST, request.FILES, instance=user)
        print(form.errors)
        if form.is_valid():
            form.save()
            return redirect('/my_profile')
    return redirect('/my_profile')

def c_update(request):
    email = request.session["email"]
    profile = Customer_reg.objects.get(email=email)
    return render(request, "c_update.html", {"profile": profile})


def customers_view_services(request):
    services = Add_Services.objects.all()
    return render(request,"customers_view_services.html",{"services":services})

def book_services(request,id):
    email = request.session["email"]
    services = Add_Services.objects.get(id=id)
    if request.method=="POST":
        contact=Book_ServicesForms(request.POST)
        if contact.is_valid():
            contact.save()
            messages.success(request, "Successfully Posted")
            return redirect("/customers_my_bookings_services")
    return render(request, "book_services.html", {"email":email,"services":services})




def customers_my_bookings_services(request):
    email = request.session["email"]
    bookings = Book_Services.objects.filter(email=email)
    return render(request,"customers_my_bookings_services.html",{"bookings":bookings})


def customers_view_notifications(request):
    notifications = Notifications.objects.all()
    return render(request,"customers_view_notifications.html",{"notifications":notifications})

