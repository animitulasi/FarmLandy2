from django import forms
from .models import Admin, Notifications


class AdminForm(forms.ModelForm):
    class Meta:
        model = Admin
        fields = "__all__"


class NotificationsForms(forms.ModelForm):
    class Meta:
        model = Notifications
        fields = "__all__"
