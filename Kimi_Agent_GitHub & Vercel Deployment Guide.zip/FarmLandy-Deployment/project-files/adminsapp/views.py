from django.contrib import messages
from django.shortcuts import render, redirect
from django.urls import reverse

from adminsapp.models import *
from customerapp.models import *
from adminsapp.forms import *
from customerapp.forms import *

# Create your views here.

def admins(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST['password']
        request.session['username'] = username
        try:
            admin = Admin.objects.get(username=username, password=password)
            return render(request, "admin_home.html", {"admin":admin,"msg": "Login Success"})
        except Exception as e:
            print(e)
            return render(request, "admin.html", {"msg":"Invalid Data"})
    return render(request, "admin.html", {})


def admin_home(request):
    return render(request, "admin_home.html", {})



def admin_chng_pwd(request):
    username = request.session.get("username")
    if not username:
        return redirect('/admin')

    if admin_login(request):
        if request.method == 'POST':
            password = request.POST.get('password')
            new_password = request.POST.get('new_password')

            # Check if the old password and new password are the same
            if password == new_password:
                messages.error(request, "Your Old Password And New Password Are The Same.")
                return redirect('admin_chng_pwd')

            # Verify old password and update new password

            try:
                user = Admin.objects.get(username=username, password=password)
                user.password = new_password
                user.save()
                messages.success(request, 'Successfully Password Changed.')
                return redirect('/admins')
            except Admin.DoesNotExist:
                messages.error(request, "Invalid Old Password.")

                return redirect('admin_chng_pwd')
        return render(request, "admin_chng_pwd.html", {"username": username})
    else:
        return redirect('/admin')


def admin_login(request):
    if request.session.__contains__('username'):
        return True
    else:
        return False


def view_all_customers(request):
    all_customers=Customer_reg.objects.all()
    return render(request, 'all_customers.html', {'all_customers':all_customers})

def accept_customers(request,id):
    all_customers = Customer_reg.objects.get(id=id)
    all_customers.status = "Accepted"
    all_customers.save()
    return redirect("/view_all_customers")

def reject_customers(request,id):
    all_customers = Customer_reg.objects.get(id=id)
    all_customers.status = "Rejected"
    all_customers.save()
    return redirect("/view_all_customers")

def view_all_properties(request,email):
    all_customers = Customer_reg.objects.get(email=email)
    others_prop = Properties.objects.filter(email=all_customers.email)
    return render(request, "all_properties.html", {'others_prop': others_prop})

def admins_accept_properties(request,id):
    others_prop = Properties.objects.get(id=id)
    others_prop.status = "Accepted"
    others_prop.save()
    return redirect(reverse('view_all_properties', kwargs={'email': others_prop.email}))

def admins_reject_properties(request,id):
    others_prop = Properties.objects.get(id=id)
    others_prop.status = "Rejected"
    others_prop.save()
    return redirect(reverse('view_all_properties', kwargs={'email': others_prop.email}))

def view_contact(request):
    contact = Contact.objects.all()
    return render(request,"view_contact.html",{"contact":contact})

def delete_my_properties(request,id):
    query = Customer_reg.objects.get(id=id)
    query.delete()
    return redirect("/view_all_customers")

def admin_all_delete(request,id):
    query=Properties.objects.get(id=id)
    query.delete()
    return redirect("/view_all_properties")


def admin_logout(request):
    request.session['username'] = ""
    return redirect("/admins")
    # return render(request, "admin.html", {"msg": "Logout Success"})

def add_services(request):
    if request.method=="POST":
        contact=Add_ServicesForms(request.POST)
        if contact.is_valid():
            contact.save()
            return redirect("/admins_view_services")
    return render(request, "add_services.html", {})


def admins_view_services(request):
    services = Add_Services.objects.all()
    return render(request,"admins_view_services.html",{"services":services})

def admins_delete_services(request,id):
    services = Add_Services.objects.get(id=id)
    services.delete()
    return redirect("/admins_view_services")

def admins_view_bookings_services(request,id):

    services = Add_Services.objects.get(id=id)
    bookings = Book_Services.objects.filter(services_id=services.id)
    return render(request,"admins_view_bookings_services.html",{"bookings":bookings})

def admins_accept_bookings_services(request,id):
    bookings = Book_Services.objects.get(id=id)
    bookings.status = "Accepted"
    bookings.save()

    return redirect("admins_view_bookings_services", id=bookings.services_id)

def admins_reject_bookings_services(request,id):
    bookings = Book_Services.objects.get(id=id)
    bookings.status = "Rejected"
    bookings.save()
    return redirect("admins_view_bookings_services", id=bookings.services_id)



def add_notifications(request):
    if request.method == "POST":
        notifications = NotificationsForms(request.POST)
        if notifications.is_valid():
            notifications.save()
            return redirect("/admins_view_notifications")
    return render(request,"add_notifications.html",{})


def admins_view_notifications(request):
    notifications = Notifications.objects.all()
    return render(request,"admins_view_notifications.html",{"notifications":notifications})

def admins_delete_notifications(request,id):
    notifications = Notifications.objects.get(id=id)
    notifications.delete()
    return redirect("/admins_view_notifications")




