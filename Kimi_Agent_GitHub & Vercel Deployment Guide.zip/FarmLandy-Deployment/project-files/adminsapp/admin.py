from django.contrib import admin
from .models import Admin, Notifications

# Register your models here.
admin.site.register(Admin)
admin.site.register(Notifications)
