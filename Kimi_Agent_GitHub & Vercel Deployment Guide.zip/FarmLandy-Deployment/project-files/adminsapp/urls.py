"""
URL configuration for adminsapp.
"""
from django.urls import path
from . import views

urlpatterns = [
    # Admin authentication
    path('', views.admins, name='admins'),
    path('admin-home/', views.admin_home, name='admin_home'),
    path('admin-logout/', views.admin_logout, name='admin_logout'),
    path('admin-chng-pwd/', views.admin_chng_pwd, name='admin_chng_pwd'),
    
    # Customer management
    path('view-all-customers/', views.view_all_customers, name='view_all_customers'),
    path('accept-customers/<int:id>/', views.accept_customers, name='accept_customers'),
    path('reject-customers/<int:id>/', views.reject_customers, name='reject_customers'),
    path('delete-my-properties/<int:id>/', views.delete_my_properties, name='delete_my_properties'),
    
    # Property management
    path('view-all-properties/<str:email>/', views.view_all_properties, name='view_all_properties'),
    path('admins-accept-properties/<int:id>/', views.admins_accept_properties, name='admins_accept_properties'),
    path('admins-reject-properties/<int:id>/', views.admins_reject_properties, name='admins_reject_properties'),
    path('admin-all-delete/<int:id>/', views.admin_all_delete, name='admin_all_delete'),
    
    # Contact
    path('view-contact/', views.view_contact, name='view_contact'),
    
    # Services
    path('add-services/', views.add_services, name='add_services'),
    path('admins-view-services/', views.admins_view_services, name='admins_view_services'),
    path('admins-delete-services/<int:id>/', views.admins_delete_services, name='admins_delete_services'),
    path('admins-view-bookings-services/<int:id>/', views.admins_view_bookings_services, name='admins_view_bookings_services'),
    path('admins-accept-bookings-services/<int:id>/', views.admins_accept_bookings_services, name='admins_accept_bookings_services'),
    path('admins-reject-bookings-services/<int:id>/', views.admins_reject_bookings_services, name='admins_reject_bookings_services'),
    
    # Notifications
    path('add-notifications/', views.add_notifications, name='add_notifications'),
    path('admins-view-notifications/', views.admins_view_notifications, name='admins_view_notifications'),
    path('admins-delete-notifications/<int:id>/', views.admins_delete_notifications, name='admins_delete_notifications'),
]
