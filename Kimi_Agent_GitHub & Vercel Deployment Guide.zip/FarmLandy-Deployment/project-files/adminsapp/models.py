from django.db import models


# Create your models here.
class Admin(models.Model):
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=30)

class Notifications(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    ndatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "Notifications"
