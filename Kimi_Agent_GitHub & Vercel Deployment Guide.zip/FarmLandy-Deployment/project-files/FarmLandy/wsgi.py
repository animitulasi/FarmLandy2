"""
WSGI config for FarmLandy project.
"""

import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'FarmLandy.settings')

application = get_wsgi_application()

# For Vercel serverless deployment
app = application
