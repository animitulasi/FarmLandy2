# FarmLandy - Farm Land Marketplace

![FarmLandy](https://img.shields.io/badge/Django-4.2-green)
![Python](https://img.shields.io/badge/Python-3.9-blue)
![License](https://img.shields.io/badge/License-MIT-yellow)

**India's First Agri Land Exchange & Trading Platform**

FarmLandy is a comprehensive web application that connects farmers and landowners with potential buyers for agricultural lands, estate lands, and agri-industrial properties.

---

## Features

### Customer Portal
- User Registration & Login
- Post Agricultural Properties
- View All Properties
- Book Site Visits (Slots)
- Services Booking
- Profile Management
- Change Password

### Admin Portal
- Admin Dashboard
- Customer Management (Accept/Reject)
- Property Management (Accept/Reject)
- Contact Messages
- Services Management
- Notifications Management

---

## Tech Stack

| Technology | Purpose |
|------------|---------|
| Django 4.2 | Backend Framework |
| Python 3.9 | Programming Language |
| PostgreSQL | Production Database |
| SQLite | Development Database |
| HTML/CSS/JS | Frontend |
| WhiteNoise | Static Files |

---

## Quick Start

### 1. Clone Repository

```bash
git clone https://github.com/YOUR_USERNAME/FarmLandy.git
cd FarmLandy
```

### 2. Create Virtual Environment

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run Migrations

```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Create Superuser

```bash
python manage.py createsuperuser
```

### 6. Run Development Server

```bash
python manage.py runserver
```

Visit: http://127.0.0.1:8000

---

## Deployment

### Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

1. Push code to GitHub
2. Import project in Vercel
3. Add environment variables
4. Deploy!

### Deploy to Railway

1. Connect GitHub repo to Railway
2. Add PostgreSQL database
3. Deploy!

See [DEPLOYMENT_GUIDE.md](documentation/DEPLOYMENT_GUIDE.md) for detailed instructions.

---

## Environment Variables

Create `.env` file:

```env
SECRET_KEY=your-secret-key
DEBUG=False
DATABASE_URL=postgres://user:pass@host/db
```

---

## Project Structure

```
FarmLandy/
├── FarmLandy/          # Main project settings
├── customerapp/        # Customer portal
├── adminsapp/          # Admin portal
├── templates/          # HTML templates
├── static/             # CSS, JS, Images
├── media/              # User uploads
├── manage.py
├── requirements.txt
└── vercel.json
```

---

## Screenshots

![Home Page](screenshots/home.png)
![Features](screenshots/features.png)

---

## Contributing

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

---

## License

This project is licensed under the MIT License.

---

## Support

For support, email support@farmlandy.com or create an issue.

---

**Made with ❤️ for Indian Farmers**
